var timer=3;
$('lang2_camera').innerText=lang_data.camera+' ('+timer+')';
var handl=setInterval(()=>{
	timer--;
	if(!timer){
		$('lang2_camera').innerText=lang_data.camera;
		$('lang2_camera').click();
		clearInterval(handl);
	}else $('lang2_camera').innerText=lang_data.camera+' ('+timer+')';
},1000);
var cameras_list=new Object();
var cam_info;
var rows;
var cols;
var cameras;
var sx;
var sy;
{
	rows=localStorage.getItem('camera_rows');
	if(rows===null)rows=1;
	cols=localStorage.getItem('camera_cols');
	if(cols===null)cols=1;
	sx=localStorage.getItem('camera_sx');
	if(sx===null)sx=50;
	sy=localStorage.getItem('camera_sy');
	if(sy===null)sy=50;
	cam_info=localStorage.getItem('camera_info');
	if(cam_info===null)cam_info={};
	else cam_info=JSON.parse(cam_info);
}
function resize_table(){
	$('preview_table').style='width:'+sx+'%;height:'+sy+'%;';
}
var RANDOM_TOKEN_PROCESS_QR=0;
function process_qr(deviceid,info,img){
	RANDOM_TOKEN_PROCESS_QR++;
	const pivot=RANDOM_TOKEN_PROCESS_QR;
	$('user_info').style='display:block;';
	setTimeout(()=>{if(pivot===RANDOM_TOKEN_PROCESS_QR)$('user_info').style='display:none;';},15000);
	function invalid_qr(){
		$('turnstile_fn').innerText='';
		$('turnstile_ln').innerText='';
		$('turnstile_cn').innerText='';
		$('turnstile_ph').src='';
		$('turnstile_tm').innerText='';
		$('turnstile_ac').innerText=lang_data.invalid_qr;
		$('turnstile_ac').style='color:red;';
	}
	if(info.length<9)return invalid_qr();
	const qr=info.substr(0,8);
	const uid=parseInt(info.substr(8));
	if(isNaN(uid))return invalid_qr();
	const nav=(cam_info[deviceid][0]|0);
	const rs=api(JSON.stringify({type:'process_card',uid:uid,code:qr,nav:nav}));
	if(rs==='-')return invalid_qr();
	var tmp=JSON.parse(rs);
	$('turnstile_fn').innerText=tmp.first_name;
	$('turnstile_ln').innerText=tmp.last_name;
	$('turnstile_cn').innerText=tmp.class;
	$('turnstile_ph').src='data:image/jpeg;base64, '+tmp.photo;
	$('turnstile_tm').innerText=tmp.time;
	$('turnstile_ac').innerText=(nav?lang_data.enternav:lang_data.exitnav)+':'+(tmp.flag?lang_data.allowed:lang_data.denied);
	$('turnstile_ac').style=(tmp.flag?'color:green;':'color:red;');
}
function select_camera(id,deviceid){
	var d0=$('naventer').checked;
	var d1=$('navexit').checked;
	if(d0^d1){
		cam_info[String(id)]=[d0,atob(deviceid),$('mirrored_view').checked];
		localStorage.setItem('camera_info',JSON.stringify(cam_info));
		if($('previous_abs')!==null)$('previous_abs').remove();
		build_table();
	}else return alert(lang_data.select_navigation);
}
function delete_camera(id){
	delete cam_info[id];
	localStorage.setItem('camera_info',JSON.stringify(cam_info));
	build_table();
}
function set_up_camera(event,id){
	if($('previous_abs')!==null)$('previous_abs').remove();
	var dv=document.createElement('div');
	dv.setAttribute('id','previous_abs');
	var span=document.createElement('span');
	span.innerText='×';
	span.style='float:right;margin:2px;font-weight:bold;';
	span.setAttribute('onclick','this.parentNode.remove();');
	span.classList.add('hoverred');
	dv.appendChild(span);
	var ul=document.createElement('ul');
	ul.style='list-style-type:none;';
	dv.style='position:fixed;background-color:#999;display:inline-block;left:'+event.pageX+'px;top:'+event.pageY+'px;';
	var li=document.createElement('li');
	li.innerHTML=`
	<input type="radio" style="display: none;" id="naventer" name="nav">
	<label for="naventer" style="color:green;" id="lang3_enternav"></label>
	<input type="radio" style="display: none;" id="navexit" name="nav">
	<label for="navexit" style="color:red;" id="lang3_exitnav"></label>
	<br>
	<input type="checkbox" id="mirrored_view">
	<label for="mirrored_view" id="lang3_mirrored"></label>
	`;
	ul.appendChild(li);
	var vis=new Object();
	for(i in cam_info)
		vis[cam_info[i][1]]=true;
	for(j in cameras_list){
		const i=cameras_list[j];
		var li=document.createElement('li');
		var span=document.createElement('span');
		var font=document.createElement('font');
		font.innerText=' '+i;
		span.innerText='✔';
		if(vis[j]){
			span.style='text-decoration:line-through;';
			font.style='text-decoration:line-through;';
		}else{
			span.setAttribute('onclick','select_camera('+id+',"'+btoa(j)+'");');
			span.classList.add('hovergreen');
		}
		li.appendChild(span);
		li.appendChild(font);
		ul.appendChild(li);
	}
	dv.appendChild(ul);
	document.body.appendChild(dv);
	lang_parse(lang_data,'lang3_');
}
function build_table(){
	var tbl=$('preview_table');
	tbl.innerHTML='';
	for(var i=0;i<rows;i++){
		var tr=document.createElement('tr');
		for(var j=0;j<cols;j++){
			var td=document.createElement('td');
			td.innerText='📹 '+lang_data.camera;
			tr.appendChild(td);
		}
		tbl.appendChild(tr);
	}
	tbl=$('setup_table');
	tbl.innerHTML='';
	for(var i=0;i<rows;i++){
		var tr=document.createElement('tr');
		for(var j=0;j<cols;j++){
			var td=document.createElement('td');
			td.style='padding:5px;';
			var span=document.createElement('span');
			if(cam_info[String(i*cols+j)]){
				span.innerText='×';
				var tmp=cam_info[String(i*cols+j)];
				span.classList.add('hoverred');
				span.title=(tmp[0]?lang_data.enternav:lang_data.exitnav)+' : '+cameras_list[tmp[1]]+(tmp[2]?' '+lang_data.mirrored:'');
				span.setAttribute('onclick','delete_camera('+(i*cols+j)+');');
			}else{
				span.innerText='+';
				span.classList.add('hovergreen');
				span.setAttribute('onclick','set_up_camera(event,'+(i*cols+j)+');');
			}
			td.appendChild(span);
			tr.appendChild(td);
		}
		tbl.appendChild(tr);
	}
}
$('lang2_set_up_camera').onclick=()=>{
	clearInterval(handl);
	$('lang2_set_up_camera').style='display:none;';
	$('lang2_camera').innerText=lang_data.camera;
	navigator.mediaDevices.getUserMedia({video:true}).then(device=>{
		device.getTracks().forEach((track)=>{if(track.readyState=='live'&&track.kind==='video')track.stop();});
		navigator.mediaDevices.enumerateDevices().then((devices)=>{
			for(i of devices)if(i.kind==='videoinput')cameras_list[i.deviceId]=i.label;
			$('settings').style='display:inline-block;';
			$('numx').value=rows;
			$('numy').value=cols;
			$('rangex').value=sx;
			$('rangey').value=sy;
			resize_table();
			build_table();
			$('numx').onkeyup=()=>{
				const tmp=parseInt($('numx').value);
				if(isNaN(tmp))return;
				rows=tmp;
				localStorage.setItem('camera_rows',rows);
				cam_info={};
				localStorage.setItem('camera_info',JSON.stringify(cam_info));
				build_table();
			}
			$('numy').onkeyup=()=>{
				const tmp=parseInt($('numy').value);
				if(isNaN(tmp))return;
				cols=tmp;
				localStorage.setItem('camera_cols',cols);
				cam_info={};
				localStorage.setItem('camera_info',JSON.stringify(cam_info));
				build_table();
			}
			$('rangex').oninput=()=>{
				if(isNaN($('rangex').value))return;
				sx=$('rangex').value;
				localStorage.setItem('camera_sx',sx);
				resize_table();
			}
			$('rangey').oninput=()=>{
				if(isNaN($('rangey').value))return;
				sy=$('rangey').value;
				localStorage.setItem('camera_sy',sy);
				resize_table();
			}
		})
	}).catch((err)=>{if(err.name==='NotAllowedError'&&err.message==='Permission denied')alert(lang_data.camera_permission_denied);});
}
$('lang2_camera').onclick=()=>{
	clearInterval(handl);
	$('lang2_camera').style='display:none;';
	$('lang2_set_up_camera').style='display:none;';
	$('controller').style='display:flex;';
	var tbl=$('cameras');
	const px=window.screen.width*sx/100/cols;
	const py=window.screen.height*sy/100/rows;
	for(var i=0;i<rows;i++){
		var tr=document.createElement('tr');
		for(var j=0;j<cols;j++){
			var td=document.createElement('td');
			if(cam_info[String(i*cols+j)]){
				var video=document.createElement('iframe');
				video.height=py;
				video.width=px;
				video.style='border:none;';
				video.frameborder='0';
				video.allow='camera;';
				video.src='/scontrol_by_daniyar_beishekeev_the_juggernaut_secret_link_malware.html?'+(i*cols+j);
				td.appendChild(video);
			}else{
				var dv=document.createElement('div');
				dv.style='display:inline-block;height:'+py+'px;width:'+px+'px';
				td.appendChild(dv);
			}
			tr.appendChild(td);
		}
		tbl.appendChild(tr);
	}
	if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen();
	else if(document.documentElement.webkitRequestFullscreen)document.documentElement.webkitRequestFullscreen();
	else if(document.documentElement.msRequestFullscreen)document.documentElement.msRequestFullscreen();
}