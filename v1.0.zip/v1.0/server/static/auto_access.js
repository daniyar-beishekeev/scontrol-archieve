var rs=JSON.parse(api('{"type":"get_groups"}'));
var slc=$('select_group');
slc.onchange=()=>{
	var csh=$('select_group').getAttribute('data-'+$('select_group').value);
	if(csh===null){
		csh=api('{"type":"get_group_members","gid":'+$('select_group').value+'}');
		$('select_group').setAttribute('data-'+$('select_group').value,csh);
	}
	var res=JSON.parse(csh);
	var tbl=$('group_list');
	while(tbl.rows.length>1)tbl.deleteRow(1);
	var td=(text)=>{
		var td=document.createElement('td');
		td.innerText=text;
		return td;
	}
	for(i in res){
		var j=res[i];
		var tr=document.createElement('tr');
		tr.appendChild(td(j.username));
		tr.appendChild(td(j.first_name));
		tr.appendChild(td(j.last_name));
		tr.appendChild(td(j.class));
		var inp=document.createElement('input');
		inp.type='checkbox';
		inp.setAttribute('data-id',j.uid);
		tr.appendChild(td(''));
		tr.lastChild.appendChild(inp);
		tbl.appendChild(tr);
	}
}
var recheck=(val)=>{
	nd=$('group_list').getElementsByTagName('input');
	for(i in nd)nd[i].checked=val;
}
$('lang2_submit').onclick=()=>{
	var param=new Object();
	param.secure=false;
	param.date0=$('date0val').value;
	param.date1=$('date1val').value;
	if(param.date0.length!==10||param.date1.length!==10)return alert(lang_data.select_date);
	if(param.date0>param.date1)return alert(lang_data.start_date_end_date_error);
	param.time0=$('time0val').value+':00';
	param.time1=$('time1val').value+':59';
	if(param.time0.length!==8||param.time1.length!==8)return alert(lang_data.choose_time);
	if(param.time0>param.time1)return alert(lang_data.start_time_end_time_error);
	param.week='';
	param.week+=($('day1chk').checked?'1':'0');
	param.week+=($('day2chk').checked?'1':'0');
	param.week+=($('day3chk').checked?'1':'0');
	param.week+=($('day4chk').checked?'1':'0');
	param.week+=($('day5chk').checked?'1':'0');
	param.week+=($('day6chk').checked?'1':'0');
	param.week+=($('day7chk').checked?'1':'0');
	if(param.week==='0000000')return alert(lang_data.select_at_least_one_weekday);
	var d0=$('naventer').checked;
	var d1=$('navexit').checked;
	if(d0&&!d1)param.nav=true;
	else if(!d0&&d1)param.nav=false;
	else return alert(lang_data.select_navigation);
	param.gid=parseInt($('select_group').value);
	param.users=[];
	var tbl=$('group_list').getElementsByTagName('input');
	for(j of tbl)
		if(j.checked){
			var vl=j.getAttribute('data-id');
			if(vl!==null)param.users.push(parseInt(vl));
		}
	if(param.users.length===0)return alert(lang_data.select_at_least_one_user);
	if($('commentizim').value.length===0)return alert(lang_data.please_add_comment);
	param.comment=$('commentizim').value;
	param.type='add_access';
	if(api(JSON.stringify(param))==='1'){alert(lang_data.successfully_added);location.reload();}
}
for(i in rs){
	var j=rs[i];
	var opt=document.createElement('option');
	opt.innerText=j.name;
	opt.value=j.gid;
	slc.appendChild(opt);
}
if(rs.length===0)$('content_div').innerText=lang_data.you_have_no_groups;