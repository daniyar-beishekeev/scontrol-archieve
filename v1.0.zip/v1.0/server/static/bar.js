var api=(data,url='/api',method='POST')=>{
	var xhr=new XMLHttpRequest();
	xhr.open(method,url,false);
	xhr.setRequestHeader('Content-Type','text/plain;charset=UTF-8');
	xhr.send(data);
	if(xhr.status===401){
		document.cookie="AUTH=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
		location.reload();
	}
	if(xhr.status===500){
		alert(lang_data['server_error']);
		location.reload();
	}
	return xhr.response;
}
const s=parseInt(api('{"type":"get_status"}'));
var HIDE_SCROLLBAR_RANDOM_TOKEN=0;
function cb(text,callback){
	var e=document.createElement('span');
	e.innerText=lang_data[text];
	e.classList.add('bar_link');
	e.onclick=(event)=>{
		document.body.classList.add('overxhd');
		$('content_div').classList.add('switch_class10');
		HIDE_SCROLLBAR_RANDOM_TOKEN++;
		var pivot=HIDE_SCROLLBAR_RANDOM_TOKEN;
		setTimeout(()=>{
			callback(event);
			$('content_div').classList.remove('switch_class10');
			$('content_div').classList.add('switch_class01');
			setTimeout(()=>{
				$('content_div').classList.remove('switch_class01');
				if(pivot===HIDE_SCROLLBAR_RANDOM_TOKEN){document.body.classList.remove('overxhd');}
			},200);
		},200);
	};
	$('link_bar').appendChild(e);
}
function load_script(url){
	var script=document.createElement('script');
	script.src=url;
	$('content_div').appendChild(script);
}
{
	var e=document.createElement('span');
	e.innerText=localStorage.getItem('username');
	e.style='font-weight:bold;height: 15px;padding-left: 8px;padding-right: 8px;margin-left: 2px;margin-right: 2px;text-decoration: none;color:#1855b8;';
	$('link_bar').appendChild(e);
}
if(s!==0){
	cb('history',()=>{
		$('content_div').innerHTML=api('','/history.html','GET');
		lang_parse(lang_data,'lang2_');
		load_script('/history.js');
	});
}
if(s===2){
	cb('camera',()=>{
		$('content_div').innerHTML=api('','/camera.html','GET');
		lang_parse(lang_data,'lang2_');
		load_script('/camera.js');
	});
}
if(s!==0&&s!==2){
	cb('add_access',()=>{
		$('content_div').innerHTML=api('','/izim.html','GET');
		lang_parse(lang_data,'lang2_');
		load_script('/izim.js');
	});
}
if(s===3){
	cb('auto_access',()=>{
		$('content_div').innerHTML=api('','/auto_access.html','GET');
		lang_parse(lang_data,'lang2_');
		load_script('/auto_access.js');
	});
	cb('users',()=>{
		$('content_div').innerHTML=api('','/users.html','GET');
		lang_parse(lang_data,'lang2_');
		load_script('/users.js');
	});
	cb('all_groups',()=>{
		$('content_div').innerHTML=api('','/groups.html','GET');
		lang_parse(lang_data,'lang2_');
		load_script('/groups.js');
	});
	cb('accesses',()=>{
		$('content_div').innerHTML=api('','/accesses.html','GET');
		lang_parse(lang_data,'lang2_');
		load_script('/accesses.js');
	});
}
cb('profile',()=>{
	$('content_div').innerHTML=api('','/profile.html','GET');
	lang_parse(lang_data,'lang2_');
	$('card_iframe').src='/print.html?'+getCookie('AUTH').slice(-1);
	$('usrname').value=localStorage.getItem('username');
	$('lang2_change_password').onclick=()=>{
		var ps=$('changeps1').value;
		if(ps!==$('changeps2').value)return alert(lang_data['passwords_didnt_match']);
		if(ps==='')return alert(lang_data['password_cant_be_empty']);
		if(api(JSON.stringify({type:'change_password',ps:ps,uid:parseInt(getCookie('AUTH').slice(-1))}))!==undefined)alert(lang_data['password_changed']);
		$('changeps1').value='';$('changeps2').value='';
	};
	var vl=parseInt(api('{"type":"my_accesses"}'));
	$('navres0').innerText=':'+(vl&2?lang_data.allowed:lang_data.denied);
	$('navres1').innerText=':'+(vl&1?lang_data.allowed:lang_data.denied);
});
cb('logout',()=>api('{"type":"logout"}'));
