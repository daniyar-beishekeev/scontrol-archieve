var rs=JSON.parse(api('{"type":"get_my_groups"}'));
var slc=$('select_group');
slc.onchange=()=>{
	var csh=$('select_group').getAttribute('data-'+$('select_group').value);
	if(csh===null){
		csh=api('{"type":"get_my_group_members","gid":'+$('select_group').value+'}');
		$('select_group').setAttribute('data-'+$('select_group').value,csh);
	}
	var res=JSON.parse(csh);
	var tbl=$('group_list');
	while(tbl.rows.length>1)tbl.deleteRow(1);
	var td=(text)=>{
		var td=document.createElement('td');
		td.innerText=text;
		return td;
	}
	for(i in res){
		var j=res[i];
		var tr=document.createElement('tr');
		tr.appendChild(td(j.username));
		tr.appendChild(td(j.first_name));
		tr.appendChild(td(j.last_name));
		tr.appendChild(td(j.class));
		tr.setAttribute('title',lang_data.last_action+' : '+j.last_action);
		var inp=document.createElement('input');
		inp.type='checkbox';
		inp.setAttribute('data-id',j.uid);
		tr.appendChild(td(''));
		tr.lastChild.appendChild(inp);
		tbl.appendChild(tr);
	}
}
var recheck=(val)=>{
	nd=$('group_list').getElementsByTagName('input');
	for(i in nd)nd[i].checked=val;
}
$('lang2_submit').onclick=()=>{
	var d0=$('day0val').checked;
	var d1=$('day1val').checked;
	var param=new Object();
	param.secure=true;
	if(d0&&!d1)param.day=false;
	else if(!d0&&d1)param.day=true;
	else return alert(lang_data.select_date);
	param.time0=$('time0val').value+':00';
	param.time1=$('time1val').value+':59';
	if(param.time0.length!==8||param.time1.length!==8)return alert(lang_data.choose_time);
	if(param.time0>param.time1)return alert(lang_data.start_time_end_time_error);
	d0=$('naventer').checked;
	d1=$('navexit').checked;
	if(d0&&!d1)param.nav=true;
	else if(!d0&&d1)param.nav=false;
	else return alert(lang_data.select_navigation);
	param.gid=parseInt($('select_group').value);
	param.users=[];
	var tbl=$('group_list').getElementsByTagName('input');
	for(j of tbl)
		if(j.checked){
			var vl=j.getAttribute('data-id');
			if(vl!==null)param.users.push(parseInt(vl));
		}
	if(param.users.length===0)return alert(lang_data.select_at_least_one_user);
	if($('commentizim').value.length===0)return alert(lang_data.please_add_comment);
	param.comment=$('commentizim').value;
	param.type='add_access';
	if(api(JSON.stringify(param))==='1'){alert(lang_data.successfully_added);location.reload();}
}
for(i in rs){
	var j=rs[i];
	var opt=document.createElement('option');
	opt.innerText=j[0];
	opt.value=j[1];
	slc.appendChild(opt);
}
if(rs.length===0)$('content_div').innerText=lang_data.you_have_no_groups;