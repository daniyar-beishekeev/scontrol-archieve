var modal_open=(id)=>{
	$(id).style.display='block';
	$(id).classList.add('modal_open');
	setTimeout(()=>$(id).classList.remove('modal_open'),200);
};
var modal_close=(id)=>{
	$(id).classList.add('modal_close');
	setTimeout(()=>{$(id).classList.remove('modal_close');$(id).style.display='none';},200);
};
$('lang2_create_user').onclick=()=>{
	modal_open('oneusermodal');
	lang_parse(lang_data,'lang3_');
};
$('lang2_create_many_users').onclick=()=>{
	modal_open('manyusermodal');
	lang_parse(lang_data,'lang4_');
	var tmp=lang_data.login+' [TAB] '+lang_data.password+' [TAB] '+lang_data.first_name+' [TAB] '+lang_data.last_name+' [TAB] '+lang_data.class;
	$('textareod').setAttribute('placeholder',tmp+'\n'+tmp+'\n...');
};
$('lang3_submit').onclick=()=>{
	var param=[$('oup0').value,$('oup1').value,$('oup2').value,$('oup3').value,$('oup4').value];
	if(param[0]==='')return alert(lang_data.login_cant_be_empty);
	if(!param[0].match(/^[0-9a-zA-Z@-@.-.]+$/))return alert(lang_data.login_can_contain_only_letters_numbers_dots_and_a);
	if(param[1]==='')return alert(lang_data.password_cant_be_empty);
	var rs=api(JSON.stringify({type:'create_user',param:param}));
	if(rs==='-')return alert(lang_data.login_busy);
	alert(lang_data.successfully_created);
	$('oup0').value='';$('oup1').value='';$('oup2').value='';$('oup3').value='';$('oup4').value='';
};
$('textareod').onkeyup=()=>{
	var tbl=$('check_script_tbl');
	while(tbl.rows.length>1)tbl.deleteRow(1);
	var data=$('textareod').value.split('\n');
	var td=(text)=>{
		var td=document.createElement('td');
		td.innerText=text;
		return td;
	}
	for(i of data){
		j=i.split('	');
		if(j.length<5)continue;
		var tr=document.createElement('tr');
		for(var k=0;k<5;k++)tr.appendChild(td(j[k]));
		if(j[0]===''){
			tr.appendChild(td(lang_data.login_cant_be_empty));
			tr.style='background-color:red;';
		}else
		if(!j[0].match(/^[0-9a-zA-Z@-@.-.]+$/)){
			tr.appendChild(td(lang_data.login_can_contain_only_letters_numbers_dots_and_a));
			tr.style='background-color:red;';
		}else
		if(j[1]===''){
			tr.appendChild(td(lang_data.password_cant_be_empty));
			tr.style='background-color:red;';
		}else{
			tr.style='background-color:cyan;';
		}
		tbl.appendChild(tr);
	}
}
$('lang4_submit').onclick=()=>{
	var tbl=$('check_script_tbl');
	while(tbl.rows.length>1)tbl.deleteRow(1);
	var data=$('textareod').value.split('\n');
	var td=(text)=>{
		var td=document.createElement('td');
		td.innerText=text;
		return td;
	}
	for(i of data){
		j=i.split('	');
		if(j.length<5)continue;
		var tr=document.createElement('tr');
		for(var k=0;k<5;k++)tr.appendChild(td(j[k]));
		if(j[0]===''){
			tr.appendChild(td(lang_data.login_cant_be_empty));
			tr.style='background-color:red;';
		}else
		if(!j[0].match(/^[0-9a-zA-Z@-@.-.]+$/)){
			tr.appendChild(td(lang_data.login_can_contain_only_letters_numbers_dots_and_a));
			tr.style='background-color:red;';
		}else
		if(j[1]===''){
			tr.appendChild(td(lang_data.password_cant_be_empty));
			tr.style='background-color:red;';
		}else{
			var rs=api(JSON.stringify({type:'create_user',param:j}));
			if(rs==='-'){
				tr.appendChild(td(lang_data.login_busy));
				tr.style='background-color:yellow;';
			}else{
				tr.appendChild(td(lang_data.successfully_created));
				tr.style='background-color:lime;';
			}
		}
		tbl.appendChild(tr);
	}
}
var auto_search=(event)=>{
	if(event.keyCode===13)$('lang2_search').click();
}
$('lang2_search').onclick=()=>{
	var param=[$('search0').value,$('search1').value,$('search2').value,$('search3').value,$('search4').value,$('search5').value];
	if(param[0]==='')return alert(lang_data.login_cant_be_empty);
	if(!param[0].match(/^[0-9a-zA-Z@-@.-.]+$/)&&param[0]!=='*')return alert(lang_data.login_can_contain_only_letters_numbers_dots_and_a);
	var rs=JSON.parse(api(JSON.stringify({type:'search_users',param:param})));
	var tbl=$('filtertable');
	while(tbl.rows.length>3)tbl.deleteRow(3);
	var td=(text,stl='')=>{
		var td=document.createElement('td');
		td.innerText=text;
		td.style=stl;
		return td;
	}
	const sts=[lang_data.standart,lang_data.manager,lang_data.operator,lang_data.administrator];
	for(i of rs){
		var tr=document.createElement('tr');
		tr.appendChild(td(i.username));
		tr.appendChild(td(i.status>>2?lang_data.banned:lang_data.active,i.status>>2?'color:red;border-color:black;':'color:green;border-color:black;'));
		tr.appendChild(td(sts[i.status&3]));
		tr.appendChild(td(i.first_name));
		tr.appendChild(td(i.last_name));
		tr.appendChild(td(i.class));
		tr.classList.add('hovere');
		tr.setAttribute('onclick','view_user(event,'+i.uid+')');
		var tmp=td('','text-align:center;');
		var inp=document.createElement('input');
		inp.type='checkbox';
		inp.setAttribute('onclick','edit_print_list(this.checked,'+i.uid+',this)');
		if(print_list[i.uid])inp.checked=true;
		tmp.appendChild(inp);
		tmp.setAttribute('ignore','1');
		tr.appendChild(tmp);
		tbl.appendChild(tr);
	}
	var tr=document.createElement('tr');
	var tmp=td(lang_data.total+':'+rs.length);
	tmp.setAttribute('colspan','7');
	tmp.style='text-align:center;background-color:cyan;';
	tr.appendChild(tmp);
	tbl.appendChild(tr);
}
var cur_user_tr;
var edupage_users=false;
var add_notification=(step)=>{
	if(step===0){
		$('user_add_notification').innerText='➕';
		$('user_add_notification').setAttribute('onclick','add_notification(1)');
		return;
	}
	if(step===1){
		$('user_add_notification').innerHTML='';
		$('user_add_notification').setAttribute('onclick','');
		const types=['','Edupage','Telegram'];
		$('user_add_notification').appendChild(document.createElement('select'));
		$('user_add_notification').lastChild.setAttribute('id','add_notification0');
		for(var i in types){
			var option=document.createElement('option');
			option.innerText=types[i];
			if(types[i]===''){
				option.disabled=true;
				option.selected=true;
			}
			option.value=types[i];
			$('add_notification0').appendChild(option);
		}
		$('add_notification0').setAttribute('onchange','add_notification(2)');
		$('user_add_notification').appendChild(document.createElement('div'));
		return;
	}
	if(step===2){
		const val=$('add_notification0').value;
		$('user_add_notification').getElementsByTagName('div')[0].innerHTML='';
		{
			if(val==='Edupage'){
				var sel=document.createElement('select');
				sel.setAttribute('id','add_notification1');
				{
					var opt=document.createElement('option');
					opt.selected=true;
					opt.disabled=true;
					opt.value='';
					sel.appendChild(opt);
				}
				if(edupage_users===false)edupage_users=JSON.parse(api('{"type":"get_edupage_users"}'));
				for(var i in edupage_users){
					var tmp=edupage_users[i].split('~');
					var option=document.createElement('option');
					option.innerText=(tmp[0].charAt(0)==='S'?lang_data.student:(tmp[0].charAt(0)==='P'?lang_data.parent:''))+' '+tmp[1];
					option.value=edupage_users[i];
					sel.appendChild(option);
				}
				$('user_add_notification').getElementsByTagName('div')[0].appendChild(sel);
			}else if(val==='Telegram'){
				var sel=document.createElement('input');
				sel.style='width:100%;';
				sel.type='number';
				sel.setAttribute('id','add_notification1');
				$('user_add_notification').getElementsByTagName('div')[0].appendChild(sel);
			}
		}
		{
			var sel=document.createElement('select');
			sel.setAttribute('id','add_notification3');
			var all=JSON.parse(api('','/lang/all.json','GET'));
			for(var j in all){
				var option=document.createElement('option');
				option.value=j;
				if(j===DEFAULT_LANGUAGE)option.selected=true;
				option.innerText=all[j];
				sel.appendChild(option);
			}
			$('user_add_notification').getElementsByTagName('div')[0].appendChild(sel);
		}
		{
			var txt=document.createElement('textarea');
			txt.maxlength=200;
			txt.setAttribute('id','add_notification2');
			txt.placeholder=lang_data.comment;
			$('user_add_notification').getElementsByTagName('div')[0].appendChild(txt);
		}
		{
			var sel=document.createElement('input');
			sel.type='button';
			sel.onclick=()=>{
				if($('add_notification1').value==='')return;
				var messa=$('add_notification3').value+'~'+$('add_notification0').value.charAt(0)+$('add_notification1').value+($('add_notification0').value==='Edupage'?'_':'~')+$('add_notification2').value.replaceAll('~','');
				if(api(JSON.stringify({type:'add_notification',uid:parseInt($('user_uid').value),address:messa}))==='1'){
					var tbl=$('user_notification');
					var tmp=messa.split('~');
					var tr=document.createElement('tr');
					function td(text){
						var td=document.createElement('td');
						td.innerText=text;
						return td;
					}
					var langs_tmp=JSON.parse(api('','/lang/all.json','GET'));
					tr.appendChild(td(langs_tmp[tmp[0]]));
					var msg='';
					if(tmp[1].charAt(0)==='E')msg='Edupage';
					else if(tmp[1].charAt(0)==='T')msg='Telegram '+tmp[1].slice(1);
					tr.appendChild(td(msg));
					tr.appendChild(td(tmp[2]));
					tr.appendChild(td('➖'));
					tr.lastChild.style='color:red;border-color:black;'
					tr.lastChild.setAttribute('onclick','delete_notification('+JSON.stringify([messa])+',this)');
					tbl.appendChild(tr);
				}
				$('user_add_notification').innerHTML='➕';
				$('user_add_notification').setAttribute('onclick','add_notification(1)');
				return;
			}
			sel.value=lang_data.submit;
			$('user_add_notification').getElementsByTagName('div')[0].appendChild(sel);
		}
		return;
	}
}
var view_user=(event,id)=>{
	if(event.target.tagName==='INPUT')return;
	if(event.target.getAttribute('ignore')==='1')return;
	cur_user_tr=event.target.parentNode;
	modal_open('viewusermodal');
	lang_parse(lang_data,'lang5_');
	var dat=JSON.parse(api(JSON.stringify({type:'get_user_data',uid:id})));
	$('userdat0').value=dat.username;
	$('userdat1').value=dat.first_name;
	$('userdat2').value=dat.last_name;
	$('userdat3').value=dat.class;
	$('last_action_id').innerText=dat.last_action;
	$('userdat4').checked=(dat.status>>2);
	$('userdat5').innerHTML='';
	var status=(dat.status&3);
	var crel=(text,vl,flag)=>{
		var elem=document.createElement('option');
		elem.innerText=text;
		elem.value=vl;
		if(flag)elem.selected=true;
		return elem;
	}
	$('userdat7').value='';
	$('userdat5').value=String(status);
	$('userdat5').appendChild(crel(lang_data.standart,'0',(0===status)));
	$('userdat5').appendChild(crel(lang_data.manager,'1',(1===status)));
	$('userdat5').appendChild(crel(lang_data.operator,'2',(2===status)));
	$('userdat5').appendChild(crel(lang_data.administrator,'3',(3===status)));
	$('userdat6').src='data:image/jpg;base64,'+dat.photo;
	$('user_uid').value=id;
	{
		var tbl=$('user_allows');
		while(tbl.rows.length>2)tbl.deleteRow(2);
		for(var i in dat.allows){
			var tr=document.createElement('tr');
			var td=(text,stl='')=>{
				var td=document.createElement('td');
				td.innerText=text;
				td.style=stl;
				return td;
			}
			tr.appendChild(td(dat.allows[i].created));
			tr.appendChild(td(dat.allows[i].start_date+' - '+dat.allows[i].end_date));
			tr.appendChild(td(`${dat.allows[i].username}►${dat.allows[i].first_name} ${dat.allows[i].last_name}@${dat.allows[i].class}`));
			tr.appendChild(td(dat.allows[i].msg));
			tr.appendChild(td(dat.allows[i].nav==='1'?lang_data.enternav:lang_data.exitnav,'border-color:black;color:'+(dat.allows[i].nav==='1'?'green':'red')));
			tr.appendChild(td(''));
			{
				var a=document.createElement('a');
				a.innerText='↗';
				a.target='_blank';
				a.href='/view_rule.html?'+dat.allows[i].aid;
				tr.lastChild.appendChild(a);
			}
			tbl.appendChild(tr);
		}
	}
	$('user_group_rights').style='display:none;'
	if(dat.status&1){
		var tbl=$('user_group_rights');
		$('user_group_rights').style='';
		while(tbl.rows.length>1)tbl.deleteRow(1);
		base644int=(x)=>{const base64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';return((base64.indexOf(x[3])<<18)|(base64.indexOf(x[2])<<12)|(base64.indexOf(x[1])<<6)|(base64.indexOf(x[0])));}
		const r=dat.group_right;
		var flag=new Object();
		for(var j=0;j<r.length;j+=4)
			flag[String(base644int(r.substr(j,4)))]=true;
		var groups=JSON.parse(api('{"type":"get_groups"}'));
		for(var i in groups){
			var tr=document.createElement('tr');
			var td=document.createElement('td');
			var td2=document.createElement('td');
			var label=document.createElement('label');
			var inp=document.createElement('input');
			inp.setAttribute('type','checkbox');
			inp.setAttribute('data-group',groups[i].gid);
			inp.onclick=()=>$('group_right_save_but').style='';
			label.setAttribute('for','userchkgrp_'+groups[i].gid);
			label.innerText=groups[i].name;
			if(flag[String(groups[i].gid)])inp.checked=true;
			td.appendChild(inp);
			td2.appendChild(label);
			tr.appendChild(td);
			tr.appendChild(td2);
			tbl.appendChild(tr);
		}
		{
			var tr=document.createElement('tr');
			var td=document.createElement('th');
			td.setAttribute('colspan','2');
			td.setAttribute('id','group_right_save_but');
			td.style='display:none;'
			var but=document.createElement('button');
			but.onclick=()=>{
				var list=$('user_group_rights').getElementsByTagName('input');
				var ar=new Array();
				for(var i in list)if(list[i].checked)ar.push(parseInt(list[i].getAttribute('data-group')));
				if(api(JSON.stringify({type:'edit_group_right',data:ar,uid:parseInt($('user_uid').value)}))==='1')$('group_right_save_but').style='display:none;'
			}
			but.innerText=lang_data.save;
			td.appendChild(but);
			tr.appendChild(td);
			tbl.appendChild(tr);
		}
	}
	{
		var tbl=$('user_notification');
		while(tbl.rows.length>1)tbl.deleteRow(1);
		tbl.rows[0].cells[1].innerText='➕';
		tbl.rows[0].cells[1].setAttribute('onclick','add_notification(1)');
		var all=dat.notification.split('`');
		var langs_tmp=JSON.parse(api('','/lang/all.json','GET'));
		for(var i=0;i+1<all.length;i++){
			var tmp=all[i].split('~');
			var tr=document.createElement('tr');
			function td(text){
				var td=document.createElement('td');
				td.innerText=text;
				return td;
			}
			tr.appendChild(td(langs_tmp[tmp[0]]));
			var msg='';
			if(tmp[1].charAt(0)==='E')msg='Edupage';
			else if(tmp[1].charAt(0)==='T')msg='Telegram '+tmp[1].slice(1);
			tr.appendChild(td(msg));
			tr.appendChild(td(tmp[2]));
			tr.appendChild(td('➖'));
			tr.lastChild.style='color:red;border-color:black;'
			tr.lastChild.setAttribute('onclick','delete_notification('+JSON.stringify([all[i]])+',this)');
			tbl.appendChild(tr);
		}
	}
}
$('new_photo').onchange=event=>{
	if(event.target.files){
		let file=event.target.files[0];
		var reader=new FileReader();
		reader.readAsDataURL(file);
		reader.onloadend=function(e){
			var image=new Image();
			image.src=e.target.result;
			image.onload=function(ev){
				var canvas=document.createElement('canvas');
				var scale=Math.min(1,400/image.height,300/image.width);
				var ctx=canvas.getContext('2d');
				canvas.width=Math.floor(image.width*scale);
				canvas.height=Math.floor(image.height*scale);
				ctx.drawImage(image,0,0,image.width*scale,image.height*scale);
				const data=canvas.toDataURL('image/jpeg').split(',')[1];
				if(api(JSON.stringify({type:'upload_picture',uid:parseInt($('user_uid').value),photo:data}))==='1')$('userdat6').src='data:image/jpg;base64,'+data;
			}
		}
	}
}
$('lang5_save').onclick=()=>{
	var dat=new Object();
	dat.username=$('userdat0').value;
	dat.first_name=$('userdat1').value;
	dat.last_name=$('userdat2').value;
	dat.class=$('userdat3').value;
	dat.password=$('userdat7').value;
	dat.status=(($('userdat4').checked?1:0)<<2)|parseInt($('userdat5').value);
	dat.uid=parseInt($('user_uid').value);
	if(dat.username==='')return alert(lang_data.login_cant_be_empty);
	if(!dat.username.match(/^[0-9a-zA-Z@-@.-.]+$/))return alert(lang_data.login_can_contain_only_letters_numbers_dots_and_a);
	if((dat.status&3)===3&&!confirm(lang_data.save))return;
	dat.type='update_profile';
	var ans=api(JSON.stringify(dat));
	if(ans==='-')return alert(lang_data.login_busy);
	cur_user_tr.cells[0].innerText=dat.username;
	cur_user_tr.cells[1].innerText=(dat.status>>2?lang_data.banned:lang_data.active);
	cur_user_tr.cells[1].style=(dat.status>>2?'color:red;border-color:black;':'color:green;border-color:black;');
	const sts=[lang_data.standart,lang_data.manager,lang_data.operator,lang_data.administrator];
	cur_user_tr.cells[2].innerText=sts[dat.status&3];
	cur_user_tr.cells[3].innerText=dat.first_name;
	cur_user_tr.cells[4].innerText=dat.last_name;
	cur_user_tr.cells[5].innerText=dat.class;
	$('userdat7').value='';
	if(dat.uid===parseInt(getCookie('AUTH').substring(24))){
		localStorage.setItem('username',dat.username);
		$('link_bar').getElementsByTagName('span')[0].innerText=dat.username;
	}
}
$('lang5_drop_qr').onclick=()=>{
	if(!confirm(lang_data.drop_qr))return;
	var dat=new Object();
	dat.uid=parseInt($('user_uid').value);
	dat.type='drop_qr';
	api(JSON.stringify(dat));
}
var print_list={};
var edit_print_list=(val,id,nd)=>{
	nd=nd.parentNode.parentNode.cells;
	if(val){
		print_list[id]=[nd[0].innerText,nd[3].innerText,nd[4].innerText,nd[5].innerText];
	}else{
		delete print_list[id];
	}
	var tbl=$('print_list_preview');
	tbl.innerHTML='';
	var td=(text)=>{
		var td=document.createElement('td');
		td.innerText=text;
		return td;
	}
	for(j in print_list){
		var i=print_list[j];
		var tr=document.createElement('tr');
		tr.appendChild(td(i[0]));
		tr.appendChild(td(i[1]));
		tr.appendChild(td(i[2]));
		tr.appendChild(td(i[3]));
		tbl.appendChild(tr);
	}
}
function delete_notification(text,nd){
	if(api(JSON.stringify({type:'delete_notification',address:text[0],uid:parseInt($('user_uid').value)}))==='1')nd.parentNode.remove();
}
$('lang2_print').onclick=()=>{
	var url=window.location.origin+'/print.html?';
	var flag=false;
	for(i in print_list){
		if(flag)url+='+';
		url+=i;
		flag=true;
	}
	if(flag)window.open(url,'_blank');
	else alert(lang_data.select_at_least_one_user);
}
lang_parse(lang_data,'lang5_');