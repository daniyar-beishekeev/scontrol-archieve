var add_group_member=(nd,id)=>{
	var rs;
	while(true){
		rs=prompt(nd.parentNode.parentNode.parentNode.parentNode.parentNode.getElementsByTagName('span')[1].innerText+':\n'+lang_data.add_user+':\n'+lang_data.enter_login);
		if(rs===null)return;
		if(rs==='')alert(lang_data.password_cant_be_empty);
		else{
			r=api(JSON.stringify({type:'add_group_member',gid:id,username:rs}));
			if(r==='?')alert(rs+'\n'+lang_data.user_is_not_exist);
			else if(r==='-')return alert(lang_data.user_already_in_group);
			else{
				var tbl=$('grouptablelist'+id);
				r=JSON.parse(r);
				var tr=document.createElement('tr');
				var td=(text)=>{
					var td=document.createElement('td');
					td.innerText=text;
					return td;
				}
				tr.appendChild(td(rs));
				var src=document.createElement('span');
				src.innerHTML='&#128269;';
				src.setAttribute('onclick','go_search(this);');
				tr.lastChild.appendChild(src);
				tr.appendChild(td(r.first_name));
				tr.appendChild(td(r.last_name));
				tr.appendChild(td(r.class));
				tr.appendChild(td(''));
				var span=document.createElement('span');
				span.innerText='×';
				span.setAttribute('onclick','delete_grp_member('+id+','+r.uid+',this);');
				tr.lastChild.appendChild(span);
				tbl.appendChild(tr);
				return alert(lang_data.successfully_added+'\n'+rs+'->'+r.first_name+' '+r.last_name+' '+r.class);
			}
		}
	}
}
var go_search=(nd)=>{
	var script=document.createElement('script');
	var id='tmp_script'+Math.random();
	script.setAttribute('id',id);
	script.innerHTML=`
		document.body.classList.add('overxhd');
		$('content_div').classList.add('switch_class10');
		setTimeout(()=>{
			$('content_div').innerHTML=api('','/users.html','GET');
			lang_parse(lang_data,'lang2_');
			load_script('/users.js');
			$('content_div').classList.remove('switch_class10');
			$('content_div').classList.add('switch_class01');
			setTimeout(()=>{
				$('content_div').classList.remove('switch_class01');
				document.body.classList.remove('overxhd');
				$('search0').value="${nd.parentNode.innerText.slice(0,-2)}";
				$('lang2_search').click();
				$('${id}').remove();
			},200);
		},200);
	`;
	document.body.appendChild(script);
}
var delete_grp_member=(gid,uid,nd)=>{
	var name='';
	for(var i=0;i<4;i++)name+=nd.parentNode.parentNode.getElementsByTagName('td')[i].innerText+' ';
	if(confirm(nd.parentNode.parentNode.parentNode.parentNode.parentNode.getElementsByTagName('span')[1].innerText+':\n'+lang_data['delete']+':\n'+name)){
		if(api(JSON.stringify({type:'remove_group_member',gid:gid,uid:uid}))==='1'){
			alert(nd.parentNode.parentNode.parentNode.parentNode.parentNode.getElementsByTagName('span')[1].innerText+':\n'+lang_data['deleted']+':\n'+name);
			nd.parentNode.parentNode.remove();
		}
	}
}
var rename_group=(nd,gid)=>{
	const name=nd.parentNode.parentNode.parentNode.parentNode.parentNode.getElementsByTagName('span')[1].innerText+':\n'+lang_data.edit_group_name+':\n';
	var rs=prompt(name,nd.parentNode.parentNode.parentNode.parentNode.parentNode.getElementsByTagName('span')[1].innerText);
	if(rs===null||rs==='')return;
	api(JSON.stringify({type:'rename_group',gid:gid,name:rs}));
	nd.parentNode.parentNode.parentNode.parentNode.parentNode.getElementsByTagName('span')[1].innerText=rs;
}
var expand_group=(nd)=>{
	const id=nd.id.substring(10);
	var dv=nd.parentNode.getElementsByClassName('spoiler_content')[0];
	dv.innerHTML='';
	var tbl=document.createElement('table');
	{
		var tr=document.createElement('tr');
		var td=document.createElement('th');
		var button=document.createElement('button');
		button.innerText=lang_data.add_user;
		button.classList.add('btn');
		button.setAttribute('onclick','add_group_member(this,'+id+');');
		var button2=document.createElement('button');
		button2.innerText=lang_data.edit_group_name;
		button2.classList.add('btn');
		button2.setAttribute('onclick','rename_group(this,'+id+');');
		td.setAttribute('colspan','4');
		td.appendChild(button);
		td.appendChild(button2);
		tr.appendChild(td);
		tbl.appendChild(tr);
	}
	var rs=JSON.parse(api('{"type":"get_group_members","gid":'+id+'}'));
	var td=(text)=>{
		var td=document.createElement('td');
		td.innerText=text;
		return td;
	}
	tbl.classList.add('group_list_table');
	tbl.setAttribute('id','grouptablelist'+id);
	{
		var th=(text)=>{
			var td=document.createElement('th');
			td.innerText=text;
			return td;
		}
		var tr=document.createElement('tr');
		tr.appendChild(th(lang_data.login));
		tr.appendChild(th(lang_data.first_name));
		tr.appendChild(th(lang_data.last_name));
		tr.appendChild(th(lang_data.class));
		tr.appendChild(th(lang_data.delete));
		tbl.appendChild(tr);
	}
	for(i in rs){
		j=rs[i];
		var tr=document.createElement('tr');
		tr.appendChild(td(j.username));
		var src=document.createElement('span');
		src.innerHTML='&#128269;';
		src.setAttribute('onclick','go_search(this);');
		tr.lastChild.appendChild(src);
		tr.appendChild(td(j.first_name));
		tr.appendChild(td(j.last_name));
		tr.appendChild(td(j.class));
		tr.appendChild(td(''));
		var span=document.createElement('span');
		span.innerText='×';
		span.setAttribute('onclick','delete_grp_member('+id+','+j.uid+',this);');
		tr.lastChild.appendChild(span);
		tbl.appendChild(tr);
	}
	dv.appendChild(tbl);
	nd.onclick=null;
}
var create_group=(id,nm)=>{
	var div=document.createElement('div');
	div.classList.add('spoiler');
	var inp=document.createElement('input');
	inp.type='checkbox';
	inp.setAttribute('id','spoilerbtn'+id);
	inp.style='display:none;';
	inp.setAttribute('onclick','expand_group(this);');
	var label=document.createElement('label');
	label.classList.add('noselect');
	label.setAttribute('for','spoilerbtn'+id);
	var span=document.createElement('span');
	span.innerHTML='&#9650;';
	span.classList.add('marker');
	var span2=document.createElement('span');
	span2.innerText=nm;
	var div2=document.createElement('div');
	div2.classList.add('spoiler_content');
	label.appendChild(span);
	label.appendChild(span2);
	div.appendChild(inp);
	div.appendChild(label);
	div.appendChild(div2);
	$('content_div').appendChild(div);
}
$('lang2_new_group').onclick=()=>{
	var rs=prompt(lang_data.new_group+'\n'+lang_data.group_name+':');
	if(rs===''||rs===null)return;
	if(rs.length>255)rs=rs.substring(0,255);
	var r=api(JSON.stringify({type:'create_group',name:rs}));
	create_group(parseInt(r),rs);
	alert(lang_data.successfully_created);
}
var list=JSON.parse(api('{"type":"get_groups"}'));
for(i of list)create_group(i.gid,i.name);