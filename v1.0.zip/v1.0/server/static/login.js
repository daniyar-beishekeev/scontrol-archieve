$('lang_enter').onclick=()=>{
	var param=[$('lang_login').value,$('lang_password').value];
	if(param[0].length===0||param[1].length===0||!param[0].match(/^[0-9a-zA-Z@-@.-.]+$/)){
		$('error_box').innerText=lang_data['wrong_login_or_password'];
		$('error_box').classList.add('shake');
		setTimeout(()=>{$('error_box').classList.remove('shake');},500);
		return;
	}
	var xhr=new XMLHttpRequest();
	xhr.open('POST','/require_webtoken',false);
	xhr.setRequestHeader('Content-Type','text/plain;charset=UTF-8');
	xhr.send(JSON.stringify(param));
	if(xhr.status!==200)return alert(lang_data['server_error']);
	if(xhr.response==='n')$('error_box').innerText=lang_data['wrong_login_or_password'];
	else if(xhr.response==='l')$('error_box').innerText=lang_data['user_blocked'];
	else{
		$('error_box').innerText='';
		localStorage.setItem('username',param[0]);
		setCookie('AUTH',xhr.response,($('remember_me').checked)?365:0);
		location.reload();
	}
	$('error_box').classList.add('shake');
	setTimeout(()=>{$('error_box').classList.remove('shake');},500);
}