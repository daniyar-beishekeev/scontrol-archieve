var getCookie=(name)=>{
	name+="=";
	let decodedCookie=decodeURIComponent(document.cookie);
	let ca=decodedCookie.split(';');
	for(let i=0;i<ca.length;i++){
		let c=ca[i];
		while(c.charAt(0)==' ')c=c.substring(1);
		if(c.indexOf(name)==0)return c.substring(name.length,c.length);
	}
	return "";
}
var lang=getCookie('lang');
if(lang==='')lang='ru';
var xhr=new XMLHttpRequest();
xhr.open('GET','/lang/'+lang+'.json',false);
xhr.send();
if(xhr.status===500)alert('SERVER ERROR');
if(xhr.status===404){
	document.cookie="lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
	location.reload();
}
const lang_data=JSON.parse(xhr.responseText);
function create_card(u){
	var div=document.createElement('div');
	div.classList.add('card');
	div.innerHTML='<table class="card_org"><tr><td class="card_org_icon"><img></td><td><span class="card_org_title"></span></td></tr></table><table class="card_content"><tr><td class="card_valign"><img class="card_photo"></td><td class="card_valign relfull"><img class="qr_code"><table class="personal_info"><tr><td class="langcard_first_name"></td><td class="fname"></td></tr><tr><td class="langcard_last_name"></td><td class="lname"></td></tr><tr><td class="langcard_class"></td><td class="cname"></td></tr></table></td></tr></table>';
	function ed(nm,vl){
		const type=div.getElementsByClassName(nm)[0].tagName;
		if(type==='SPAN')div.getElementsByClassName(nm)[0].innerText=vl;
		else if(type==='IMG')div.getElementsByClassName(nm)[0].src=vl;
		else if(type==='TD')div.getElementsByClassName(nm)[0].innerText=vl;
	}
	ed('card_org_title',lang_data['scontrol']);
	ed('card_photo','data:image/jpeg;base64, '+u.photo);
	ed('langcard_first_name',lang_data['first_name']);
	ed('fname',':'+u.first_name);
	ed('langcard_last_name',lang_data['last_name']);
	ed('lname',':'+u.last_name);
	ed('langcard_class',lang_data['class']);
	ed('cname',':'+u.class);
	ed('qr_code',u.id);
	return div;
}
var xhra=new XMLHttpRequest();
xhra.open('POST','/api',false);
xhra.setRequestHeader('Content-Type','text/plain;charset=UTF-8');
var ar=new Array();
location.search.slice(1).split('+').forEach(e=>{
	e=parseInt(e);
	if(!isNaN(e))ar.push(e);
});
xhra.send(JSON.stringify({type:'get_cards',cards:ar}));
if(xhra.status===401){
	document.cookie="AUTH=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
	location.reload();
}
if(xhra.status===500)alert(lang_data['server_error']);
const data=JSON.parse(xhra.responseText);
var flag=false;
var tbl=document.getElementById('mytable');
for(i of data){
	flag=!flag;
	if(flag)tbl.appendChild(document.createElement('tr'));
	var td=document.createElement('td');
	td.appendChild(create_card(i));
	tbl.lastChild.appendChild(td);
}
if(window.location===window.parent.location)window.print();