const DEFAULT_LANGUAGE='ru';
var $=(id)=>{return document.getElementById(id);};
var getCookie=(name)=>{
	name+="=";
	let decodedCookie=decodeURIComponent(document.cookie);
	let ca=decodedCookie.split(';');
	for(let i=0;i<ca.length;i++){
		let c=ca[i];
		while(c.charAt(0)==' ')c=c.substring(1);
		if(c.indexOf(name)==0)return c.substring(name.length,c.length);
	}
	return "";
}
var setCookie=(cname,cvalue,exdays)=>{
	const d=new Date();
	d.setTime(d.getTime()+(exdays*24*60*60*1000));
	let expires="expires="+d.toUTCString();
	if(!exdays)expires='';
	document.cookie=cname+"="+cvalue+";"+expires+";path=/";
}
var lang=localStorage.getItem('lang');
if(lang===null)lang=DEFAULT_LANGUAGE;
var xhr=new XMLHttpRequest();
xhr.open('GET','/lang/'+lang+'.json',false);
xhr.send();
if(xhr.status===500)alert('SERVER ERROR');
if(xhr.status===404){
	document.cookie="lang=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
	location.reload();
}
const lang_data=JSON.parse(xhr.responseText);
function lang_parse(data,pref='lang_'){
	for(i in data){
		const elem=document.getElementById(pref+i);
		if(elem===null)continue;
		var fr;
		if(elem.tagName==='INPUT')fr='placeholder';
		else fr='innerText';
		elem[fr]=data[i];
	}
}
lang_parse(lang_data);
var xhr3=new XMLHttpRequest();
xhr3.open('GET','/lang/all.json',false);
xhr3.send();
if(xhr3.status===500)alert(lang_data['server_error']);
const langs=JSON.parse(xhr3.responseText);
var select_elem=document.getElementById('languages_select');
for(i in langs){
	var option=document.createElement('option');
	option.innerText=langs[i];
	option.value=i;
	if(i===lang)option.setAttribute('selected','true');
	select_elem.appendChild(option);
}
select_elem.onchange=(e)=>{
	localStorage.setItem('lang',e.target.value);
	location.reload();
};