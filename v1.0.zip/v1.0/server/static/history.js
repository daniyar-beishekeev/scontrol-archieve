var t_datetime=(pivot=0)=>{let date_ob=new Date(new Date().getTime()+pivot);let date=('0'+date_ob.getDate()).slice(-2);let month=('0'+(date_ob.getMonth()+1)).slice(-2);let year=date_ob.getFullYear();let hours=('0'+date_ob.getHours()).slice(-2);let minutes=('0'+date_ob.getMinutes()).slice(-2);let seconds=('0'+date_ob.getSeconds()).slice(-2);return(year+'-'+month+'-'+date+'T'+hours+':'+minutes+':'+seconds);}
$('tm0').value=t_datetime(-86400000);
$('tm1').value=t_datetime();
var auto_search=(event)=>{
	if(event.keyCode===13)$('lang2_search').click();
}
$('lang2_search').onclick=()=>{
	var p={type:'get_history',a:$('tm0').value,b:$('tm1').value,c:$('lang2_login').value};
	if(p.a.length!==19||p.b.length!==19)return alert(lang_data.choose_time);
	if(p.a>p.b)return alert(lang_data.start_time_end_time_error);
	p.a[10]=' ';
	p.b[10]=' ';
	var rs=JSON.parse(api(JSON.stringify(p)));
	var tbl=$('history_table');
	while(tbl.rows.length>2)tbl.deleteRow(2);
	function td(text,stl=''){
		var td=document.createElement('td');
		td.innerText=text;
		td.style=stl;
		return td;
	}
	for(var i in rs){
		var tr=document.createElement('tr');
		tr.appendChild(td(rs[i].tm));
		tr.appendChild(td(rs[i].u0));
		tr.appendChild(td(rs[i].u1));
		tr.appendChild(td(rs[i].u2));
		tr.appendChild(td(rs[i].nav==='1'?lang_data.enternav:lang_data.exitnav,rs[i].nav==='1'?'color:green;border-color:black;':'color:red;border-color:black;'));
		tr.appendChild(td(rs[i].gv0+' '+rs[i].gv1));
		if(s===3){
			var a=document.createElement('a');
			a.innerText='↗';
			a.target='_blank';
			a.href='/view_rule.html?'+rs[i].aid;
			tr.lastChild.appendChild(a);
		}
		tr.lastChild.setAttribute('title',lang_data.created_time+' : '+rs[i].created+'\n'+lang_data.operator+' : '+rs[i].op0+' '+rs[i].op1);
		tr.appendChild(td(rs[i].msg));
		tr.classList.add('hovera');
		tbl.appendChild(tr);
	}
	{
		var tr=document.createElement('tr');
		var td=document.createElement('th');
		td.innerText=lang_data.total+' : '+rs.length;
		td.setAttribute('colspan','7');
		td.style='background-color:cyan;';
		tr.appendChild(td);
		tbl.appendChild(tr);
	}
}