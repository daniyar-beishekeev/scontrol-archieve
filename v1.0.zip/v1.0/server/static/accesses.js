var rs=JSON.parse(api('{"type":"get_accesses"}'));
rs.reverse();
var tbl=$('all_list');
var td=(text,stl='')=>{
	var td=document.createElement('td');
	td.innerText=text;
	td.style=stl;
	return td;
}
var chk=(flag)=>{
	var td=document.createElement('td');
	var inp=document.createElement('input');
	inp.type='checkbox';
	inp.disabled=true;
	inp.checked=flag;
	td.appendChild(inp);
	return td;
}
var go_search=(username)=>{
	var script=document.createElement('script');
	var id='tmp_script'+Math.random();
	script.setAttribute('id',id);
	script.innerHTML=`
		document.body.classList.add('overxhd');
		$('content_div').classList.add('switch_class10');
		setTimeout(()=>{
			$('content_div').innerHTML=api('','/users.html','GET');
			lang_parse(lang_data,'lang2_');
			load_script('/users.js');
			$('content_div').classList.remove('switch_class10');
			$('content_div').classList.add('switch_class01');
			setTimeout(()=>{
				$('content_div').classList.remove('switch_class01');
				document.body.classList.remove('overxhd');
				$('search0').value="${username}";
				$('lang2_search').click();
				$('${id}').remove();
			},200);
		},200);
	`;
	document.body.appendChild(script);
}
for(i of rs){
	var tr=document.createElement('tr');
	var stl;
	tr.appendChild(td(i.created));
	{
		var a=document.createElement('a');
		a.innerText='↗';
		a.target='_blank';
		a.href='/view_rule.html?'+i.aid;
		tr.lastChild.appendChild(a);
	}
	if(new Date(new Date().getTime()-new Date().getTimezoneOffset()*60000).getTime()<new Date(i.start_date).getTime())stl='background-color:cyan;'
	else if(new Date(new Date().getTime()-new Date().getTimezoneOffset()*60000).getTime()<=new Date(i.end_date).getTime()+86400000)stl='background-color:lime;';
	else stl='background-color:red';
	tr.appendChild(td(i.start_date,stl));
	tr.appendChild(td(i.end_date,stl));
	tr.appendChild(td(i.start_time));
	tr.appendChild(td(i.end_time));
	const tmp=('0000000'+i.week_day).slice(-7);
	for(var j=0;j<7;j++)tr.appendChild(chk(tmp.charAt(j)==='1'));
	tr.appendChild(td(i.username));
	{
		var src=document.createElement('span');
		src.innerHTML='&#128269;';
		src.setAttribute('onclick','go_search("'+i.username+'");');
		tr.lastChild.appendChild(src);
	}
	tr.appendChild(td(i.nav==='1'?lang_data.enternav:lang_data.exitnav,i.nav==='1'?'color:green;':'color:red;'));
	tr.appendChild(td(i.msg));
	tr.appendChild(td(i.users));
	tr.classList.add('hovera');
	tbl.appendChild(tr);
}