const express=require('express');
const cookie_parser=require('cookie-parser');
const mysql=require('mysql');
const web=express();
const web_redirect=express();
const https=require('https');
const http=require('http');
const fs=require('fs');
const util=require('util');
const QRcode=require('qrcode');
const config=JSON.parse(fs.readFileSync('config.json'));
const lang_script=JSON.parse(fs.readFileSync('lang_scripts.json'));
const {Telegraf}=require('telegraf');
const db=mysql.createConnection({...config.database,dateStrings:true});
web.use(express.static('static'));
web.use(express.text({limit:'8mb'}));
web.use(cookie_parser());
JSOB=(data)=>{try{data=JSON.parse(data);}catch(e){data={};}return data;};
const dbq=util.promisify(db.query).bind(db);
qca=(res,code)=>{res.sendStatus(code);};
generate=(length,characters='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789')=>{var result='';for(var i=0;i<length;i++)result+=characters.charAt(Math.floor(Math.random()*characters.length));return result;}
int4base64=(x)=>{const base64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';var str='';str+=base64[x&63];x>>=6;str+=base64[x&63];x>>=6;str+=base64[x&63];x>>=6;str+=base64[x&63];return str;}
base644int=(x)=>{const base64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';return((base64.indexOf(x[3])<<18)|(base64.indexOf(x[2])<<12)|(base64.indexOf(x[1])<<6)|(base64.indexOf(x[0])));}
t_time=(pivot=0)=>{let date_ob=new Date(new Date().getTime()+pivot);let hours=('0'+date_ob.getHours()).slice(-2);let minutes=('0'+date_ob.getMinutes()).slice(-2);let seconds=('0'+date_ob.getSeconds()).slice(-2);return(hours+':'+minutes+':'+seconds);}
t_date=(pivot=0)=>{let date_ob=new Date(new Date().getTime()+pivot);let date=('0'+date_ob.getDate()).slice(-2);let month=('0'+(date_ob.getMonth()+1)).slice(-2);let year=date_ob.getFullYear();return(year+'-'+month+'-'+date);}
t_datetime=(pivot=0)=>{let date_ob=new Date(new Date().getTime()+pivot);let date=('0'+date_ob.getDate()).slice(-2);let month=('0'+(date_ob.getMonth()+1)).slice(-2);let year=date_ob.getFullYear();let hours=('0'+date_ob.getHours()).slice(-2);let minutes=('0'+date_ob.getMinutes()).slice(-2);let seconds=('0'+date_ob.getSeconds()).slice(-2);return(year+'-'+month+'-'+date+' '+hours+':'+minutes+':'+seconds);}
t_weekday=(pivot=0)=>{let date_ob=new Date(new Date().getTime()+pivot);return (date_ob.getDay()+6)%7;}
class Edupage{
	constructor(param){
		this.edomain=`https://${param.domain}.edupage.org`;
		this.auth={username:param.login,password:param.password};
		this.client=require('request').defaults({jar:true});
		this.logined=false;
	}
	login(){
		return new Promise(rs=>{
			this.client.get(this.edomain+'/login/index.php',(error,response,body)=>{
				try{
					if(error)rs(false);
					let csrf_token=(body.split("name=\"csrfauth\" value=\"",2)[1].split("\"",1)[0]);
					let param=new Object();
					param.url=this.edomain+'/login/edubarLogin.php';
					param.form={...this.auth,csrfauth:csrf_token};
					this.client.post(param,(err,resp,body)=>{
						if(err)rs(false);
						this.client.get(this.edomain+'/user/?',async(err,response,data)=>{
							try{
								data=JSON.parse(data.split("$j(document).ready(function() {",2)[1].split(");",1)[0].replace("\t","").split("userhome(",2)[1].replace("\n","").replace("\r",""));
								var users=new Array();
								for(var i in data.dbi.students)users.push('Student'+data.dbi.students[i].id+'~'+data.dbi.students[i].firstname+' '+data.dbi.students[i].lastname);
								for(var i in data.dbi.teachers)users.push('Ucitel'+data.dbi.teachers[i].id+'~'+data.dbi.teachers[i].firstname+' '+data.dbi.teachers[i].lastname);
								for(var i in data.dbi.parents)users.push('Parent'+data.dbi.parents[i].id+'~'+data.dbi.parents[i].firstname+' '+data.dbi.parents[i].lastname);
								require('fs').writeFileSync('edupage_users.json',JSON.stringify(users));
								rs(true);
							}catch(e){
								rs(false);
							}
						});
					});
				}catch(e){
					rs(false);
				}
			});
		});
	}
	async send_message(id,text,trying=5){
		if(trying===0)return;
		if(!this.logined){
			this.logined=await this.login();
			this.send_message(id,text,trying-1);
			return;
		}
		await this.client.post({url:this.edomain+'/timeline/?akcia=createItem',headers:{accept:'application/json, text/javascript, */*; q=0.01','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','x-requested-with': 'XMLHttpRequest',referrer:this.edomain+'/'},body:'eqap='+encodeURIComponent(btoa(new URLSearchParams({attachements:'{}',receipt:'1',selectedUser:id,text:text,typ:'sprava'}).toString()))+'&eqaz=0'},async(err,res)=>{
			if(res.statusCode!==200){
				this.logined=await this.login();
				this.send_message(id,text,trying-1);
			}
		});
	}
}
var edupage,bot;
if(config.edupage){
	edupage=new Edupage(config.edupage);
	edupage.logined=edupage.login();
}
if(config.telegram){
	bot=new Telegraf(config.telegram.token);
	bot.on('text',async(ctx)=>{
		try{
			var rs=await dbq('SELECT phone IS NULL AS av FROM telegram WHERE tid=?',[ctx.message.chat.id]);
			if(!rs.length){
				await dbq('INSERT INTO telegram(tid) VALUES(?)',[ctx.message.chat.id]);
				rs=[{av:1}];
			}
			if(rs[0].av)ctx.reply('Please, indicate your contact\nПожалуйста, укажите номер телефона',{reply_markup:{keyboard:[[{text:'Indicate contact/Указать контакт',request_contact:true}]],resize_keyboard:true}});
			else ctx.reply('Your accound is already activated\nВаш аккаунт уже активирован');
		}catch(e){}
	});
	bot.on('contact',async(ctx)=>{
		try{
			if(ctx.message.contact.user_id===ctx.message.from.id){
				await dbq('UPDATE telegram SET phone=NULL WHERE phone=? LIMIT 1',[parseInt(ctx.message.contact.phone_number)]);
				await dbq('UPDATE telegram SET phone=? WHERE tid=? LIMIT 1',[parseInt(ctx.message.contact.phone_number),ctx.message.from.id]);
				ctx.reply('Thank you!/Спасибо!',{reply_markup:{remove_keyboard:true}});
			}
		}catch(e){}
	});
	bot.launch();
}
web.get('/',(req,res)=>{
	if(req.cookies.AUTH===undefined)res.sendFile(__dirname+'/page/login.html');
	else res.sendFile(__dirname+'/page/dashboard.html');
});
web.post('/require_webtoken',async(req,res)=>{
	try{
		const data=JSOB(req.body);
		if(!util.isArray(data))return qca(res,400);
		if(data.length!==2)return qca(res,400);
		var rs=await dbq('SELECT status>>2 AS block,uid FROM users WHERE username=? AND password=SHA2(?,256) LIMIT 1',[data[0],data[1]]);
		if(!rs.length)res.end('n');
		else if(rs[0].block)res.end('l');
		else{
			const hash=generate(24);
			await dbq('UPDATE users SET web=? WHERE uid=? LIMIT 1',[hash,rs[0].uid]);
			res.end(hash+rs[0].uid);
		}
	}catch(e){
		qca(res,500);
	}
});
web.post('/api',async(req,res)=>{
	try{
		if(req.cookies.AUTH===undefined||req.cookies.AUTH.length<24)return qca(res,400);
		const uid=parseInt(req.cookies.AUTH.substr(24));
		const hash=req.cookies.AUTH.substr(0,24);
		const api=JSOB(req.body);
		const usr=await dbq('SELECT status FROM users WHERE uid=? AND web=? LIMIT 1',[uid,hash]);
		if(usr.length===0)return qca(res,401);
		const status=usr[0].status;
		if(api.type==='get_status')return res.end(String(status));
		if(api.type==='logout'){
			await dbq('UPDATE users SET web=SUBSTRING(SHA1(RAND()),1,24) WHERE uid=? LIMIT 1',[uid]);
			return qca(res,401);
		}
		if(api.type==='get_cards'){
			if(status===3){
				var vl=new Array();
				for(i of api.cards){
					var rs=await dbq('SELECT first_name,last_name,class,qr,photo FROM users WHERE uid=? LIMIT 1',[i]);
					rs[0].id=await QRcode.toDataURL(rs[0].qr+i,{margin:1,small:true});
					delete rs[0].qr
					vl.push(rs[0]);
				}
				res.end(JSON.stringify(vl));
			}else{
				var rs=await dbq('SELECT first_name,last_name,class,photo,qr FROM users WHERE uid=? LIMIT 1',[uid]);
				rs[0].id=await QRcode.toDataURL(rs[0].qr+uid,{margin:1,small:true});
				delete rs[0].qr;
				res.end(JSON.stringify(rs));
			}
			return;
		}
		if(api.type==='change_password'){
			if(api.ps==='')return qca(res,400);
			if(api.uid===uid){
				await dbq('UPDATE users SET password=SHA2(?,256) WHERE uid=? LIMIT 1',[api.ps,uid]);
				qca(res,200);
			}
			return;
		}
		if(api.type==='create_user'){
			if(status!==3)return qca(res,403);
			if(api.param[0]==='')return qca(res,400);
			if(api.param[1]==='')return qca(res,400);
			if(!api.param[0].match(/^[0-9a-zA-Z@-@.-.]+$/))return qca(res,400);
			var rs=await dbq('SELECT COUNT(*) AS cnt FROM users WHERE username=? LIMIT 1',[api.param[0]]);
			if(rs[0].cnt)return res.end('-');
			var rs2=await dbq('INSERT INTO users(username,password,first_name,last_name,class) VALUES(?,SHA2(?,256),?,?,?)',api.param);
			res.end(String(rs2.insertId));
			return;
		}
		if(api.type==='search_users'){
			if(status!==3)return qca(res,403);
			if(api.param[0]==='')return qca(res,400);
			var sql='';
			var p=new Array();
			var flag=false;
			if(api.param[0]!=='*'){
				sql+=' username LIKE ?';
				p.push('%'+api.param[0]+'%');
				flag=true;
			}
			if(api.param[3]!==''){
				if(flag)sql+=' AND';
				sql+=' first_name LIKE ?';
				p.push('%'+api.param[3]+'%');
				flag=true;
			}
			if(api.param[4]!==''){
				if(flag)sql+=' AND';
				sql+=' last_name LIKE ?';
				p.push('%'+api.param[4]+'%');
				flag=true;
			}
			if(api.param[5]!==''){
				if(flag)sql+=' AND';
				sql+=' class LIKE ?';
				p.push('%'+api.param[5]+'%');
				flag=true;
			}
			if(api.param[1]!=='-'){
				if(flag)sql+=' AND';
				sql+=' status>>2=?';
				p.push(api.param[1]);
				flag=true;
			}
			if(api.param[2]!=='-'){
				if(flag)sql+=' AND';
				sql+=' status&3=?';
				p.push(api.param[2]);
				flag=true;
			}
			if(flag)sql='SELECT uid,username,status,first_name,last_name,class FROM users WHERE'+sql;
			else sql='SELECT uid,username,status,first_name,last_name,class FROM users';
			var rs=await dbq(sql,p);
			res.end(JSON.stringify(rs));
			return;
		}
		if(api.type==='create_group'){
			if(status!==3)return qca(res,403);
			var rs=await dbq('INSERT INTO grp (name) VALUES (?)',[api.name]);
			res.end(String(rs.insertId));
			return;
		}
		if(api.type==='get_groups'){
			if(status!==3)return qca(res,403);
			var rs=await dbq('SELECT gid,name FROM grp');
			res.end(JSON.stringify(rs));
			return;
		}
		if(api.type==='get_group_members'){
			if(status!==3)return qca(res,403);
			var rs=await dbq('SELECT member FROM grp WHERE gid=? LIMIT 1',[api.gid]);
			var r=rs[0].member;
			var vl=new Array();
			for(var i=0;i<r.length;i+=4){
				var rs2=await dbq('SELECT uid,username,first_name,last_name,class FROM users WHERE uid=? LIMIT 1',[base644int(r.substr(i,4))]);
				vl.push(rs2[0]);
			}
			res.end(JSON.stringify(vl));
			return;
		}
		if(api.type==='add_group_member'){
			if(status!==3)return qca(res,403);
			var rs=await dbq('SELECT uid,first_name,last_name,class FROM users WHERE username=? LIMIT 1',[api.username]);
			if(!rs.length)return res.end('?');
			var bs=int4base64(rs[0].uid);
			var rs2=await dbq('SELECT member FROM grp WHERE gid=? LIMIT 1',[api.gid]);
			r=rs2[0].member;
			flag=true;
			for(var i=0;i<r.length;i+=4)
				if(r.substr(i,4)===bs){
					flag=false;
					break;
				}
			if(flag){
				var rs3=await dbq('UPDATE grp SET member=CONCAT(member,?) WHERE gid=? LIMIT 1',[bs,api.gid]);
				res.end(JSON.stringify(rs[0]));
			}else res.end('-');
			return;
		}
		if(api.type==='remove_group_member'){
			if(status!==3)return qca(res,403);
			var bs=int4base64(api.uid);
			var rs=await dbq('SELECT member FROM grp WHERE gid=? LIMIT 1',[api.gid]);
			r=rs[0].member;
			for(var i=0;i<r.length;i+=4)
				if(r.substr(i,4)===bs){
					await dbq('UPDATE grp SET member=CONCAT(LEFT(member,?),RIGHT(member,?)) WHERE gid=? LIMIT 1',[i,r.length-i-4,api.gid]);
					res.end('1');
					return;
				}
			res.end('0');
			return;
		}
		if(api.type==='rename_group'){
			if(status!==3)return qca(res,403);
			await dbq('UPDATE grp SET name=? WHERE gid=? LIMIT 1',[api.name,api.gid]);
			qca(res,200);
			return;
		}
		if(api.type==='get_my_groups'){
			if(!(status&1))return qca(res,403);
			var rs=await dbq('SELECT group_right FROM users WHERE uid=? LIMIT 1',[uid]);
			r=rs[0].group_right;
			var vl=new Array();
			for(var i=0;i<r.length;i+=4){
				const gid=base644int(r.substr(i,4));
				var rs2=await dbq('SELECT name FROM grp WHERE gid=? LIMIT 1',[gid]);
				vl.push([rs2[0].name,gid]);
			}
			res.end(JSON.stringify(vl));
			return;
		}
		if(api.type==='get_my_group_members'){
			if(!(status&1))return qca(res,403);
			var rs=await dbq('SELECT group_right FROM users WHERE uid=? LIMIT 1',[uid]);
			r=rs[0].group_right;
			for(var i=0;i<r.length;i+=4){
				const gid=base644int(r.substr(i,4));
				if(gid===api.gid){
					var rs2=await dbq('SELECT member FROM grp WHERE gid=? LIMIT 1',[gid]);
					r=rs2[0].member;
					var vl=new Array();
					for(var i=0;i<r.length;i+=4){
						const uid2=base644int(r.substr(i,4));
						var rs3=await dbq('SELECT first_name,last_name,class,username,last_action FROM users WHERE uid=? LIMIT 1',[uid2]);
						rs3[0].uid=uid2;
						vl.push(rs3[0]);
					}
					return res.end(JSON.stringify(vl));
				}
			}
			qca(res,400);
			return;
		}
		if(api.type==='add_access'){
			if(!(status&1))return qca(res,403);
			if(api.secure){
				var rs=await dbq('SELECT group_right FROM users WHERE uid=? LIMIT 1',[uid]);
				r=rs[0].group_right;
				var chkch=true;
				for(var i=0;i<r.length;i+=4){
					const gid=base644int(r.substr(i,4));
					if(gid===api.gid){
						chkch=false;
						var rs2=await dbq('SELECT member FROM grp WHERE gid=? LIMIT 1',[gid]);
						r=rs2[0].member;
						var vis=new Object();
						for(var i=0;i<r.length;i+=4)
							vis[base644int(r.substr(i,4))]=true;
						for(i of api.users)
							if(!vis[i])return qca(res,400);
						api.date0=api.date1=t_date(api.day?86400000:0);
						var tmp=[0,0,0,0,0,0,0];
						tmp[t_weekday(api.day?86400000:0)]=1;
						api.week=tmp.join('');
					}
				}
				if(chkch)return qca(res,403);
			}else{
				if(status!==3)return qca(res,403);
			}
			db.beginTransaction(async err=>{
				if(err)return qca(res,500);
				try{
					var list_users='';
					for(i of api.users)list_users+=int4base64(i);
					const aid=await dbq('INSERT INTO allow_info (start_date,end_date,week_day,start_time,end_time,nav,gived,msg,created,users) VALUES (?,?,b?,?,?,b?,?,?,?,?)',[api.date0,api.date1,api.week,api.time0,api.time1,api.nav?'1':'0',uid,api.comment,t_datetime(),list_users]);
					const lid=int4base64(aid.insertId);
					for(i of api.users)await dbq('UPDATE users SET allows=CONCAT(allows,?) WHERE uid=? LIMIT 1',[lid,i]);
					db.commit(err=>{
						if(err){
							db.rollback();
							return qca(res,500);
						}
						return res.end('1');
					});
				}catch(e){
					db.rollback();
					return qca(res,500);
				}
			});
			return;
		}
		if(api.type==='get_accesses'){
			if(status!==3)return qca(res,403);
			var rs=await dbq('SELECT allow_info.aid,allow_info.start_date,allow_info.end_date,BIN(allow_info.week_day) AS week_day,LEFT(allow_info.start_time,5) AS start_time,LEFT(allow_info.end_time,5) AS end_time,BIN(allow_info.nav) AS nav,allow_info.msg,allow_info.created,users.username,allow_info.users FROM allow_info JOIN users ON allow_info.gived=users.uid WHERE allow_info.users!=\'\'');
			for(i in rs)rs[i].users=rs[i].users.length>>2;
			res.end(JSON.stringify(rs));
			return;
		}
		if(api.type==='get_access'){
			if(status!==3)return qca(res,403);
			var rs=await dbq('SELECT allow_info.start_date,allow_info.end_date,BIN(allow_info.week_day) AS week_day,LEFT(allow_info.start_time,5) AS start_time,LEFT(allow_info.end_time,5) AS end_time,BIN(allow_info.nav) AS nav,allow_info.msg,allow_info.created,users.username,users.first_name,users.last_name,users.class,allow_info.users FROM allow_info JOIN users ON allow_info.gived=users.uid WHERE aid=? LIMIT 1',[api.aid]);
			for(i in rs){
				var r=rs[i].users;
				var list=new Array();
				for(var j=0;j<r.length;j+=4){
					var tmp=await dbq('SELECT username,first_name,last_name,class FROM users WHERE uid=? LIMIT 1',[base644int(r.substr(j,4))]);
					list.push(tmp[0]);
				}
				rs[i].users=list;
			}
			res.end(JSON.stringify(rs));
			return;
		}
		if(api.type==='clear_access'){
			if(status!==3)return qca(res,403);
			var rs=await dbq('SELECT users FROM allow_info WHERE aid=? LIMIT 1',[api.aid]);
			if(!rs.length)return qca(res,400);
			var r=rs[0].users;
			for(var i=0;i<r.length;i+=4){
				var a=await dbq('SELECT allows FROM users WHERE uid=? LIMIT 1',[base644int(r.substr(i,4))]);
				if(!a.length)continue;
				a=a[0].allows;
				for(var j=0;j<a.length;j+=4){
					if(base644int(a.substr(j,4))===api.aid){
						await dbq('UPDATE users SET allows=? WHERE uid=? LIMIT 1',[a.substr(0,j)+a.substr(j+4,a.length-j-4),base644int(r.substr(i,4))]);
						break;
					}
				}
			}
			await dbq('UPDATE allow_info SET users=\'\' WHERE aid=?',[api.aid]);
			res.end('1');
			return;
		}
		if(api.type==='my_accesses'){
			const rs=await dbq('SELECT allows FROM users WHERE uid=? LIMIT 1',[uid]);
			const r=rs[0].allows;
			var flag=0;
			const datetime=t_date();
			const time=t_time();
			const wday=6-t_weekday();
			for(var i=0;i<r.length;i+=4){
				const a=await dbq('SELECT BIN(nav) AS nav FROM allow_info WHERE aid=? AND DATE(?) BETWEEN start_date AND end_date AND TIME(?) BETWEEN start_time AND end_time AND week_day>>?&1 LIMIT 1',[base644int(r.substr(i,4)),datetime,time,wday]);
				if(a.length)flag|=(a[0].nav==='0'?1:2);
			}
			res.end(String(flag));
			return;
		}
		if(api.type==='process_card'){
			if(status!==2)return qca(res,403);
			var rs=await dbq('SELECT allows,first_name,last_name,class,notification,photo FROM users WHERE uid=? AND qr=? LIMIT 1',[api.uid,api.code]);
			if(!rs.length)return res.end('-');
			if(api.nav!==0&&api.nav!==1)return qca(res,400);
			rs=rs[0];
			const r=rs.allows;
			rs.flag=false;
			const datetime=t_date();
			const time=t_time();
			const wday=6-t_weekday();
			const fulltime=t_datetime();
			var aid;
			for(var i=0;i<r.length;i+=4){
				const a=await dbq('SELECT COUNT(*) AS nav FROM allow_info WHERE aid=? AND DATE(?) BETWEEN start_date AND end_date AND TIME(?) BETWEEN start_time AND end_time AND week_day>>?&1 AND nav=? LIMIT 1',[base644int(r.substr(i,4)),datetime,time,wday,api.nav]);
				if(a[0].nav){
					aid=base644int(r.substr(i,4));
					rs.flag=true;
					break;
				}
			}
			rs.time=fulltime;
			var notif=rs.notification.split('`');
			delete rs['allows'];
			delete rs['notification'];
			if(rs.flag){
				db.beginTransaction(async err=>{
					if(err)return qca(res,500);
					try{
						await dbq('UPDATE users SET last_action=? WHERE uid=? LIMIT 1',[fulltime,api.uid]);
						await dbq('INSERT INTO history VALUES(?,?,?,?)',[api.uid,fulltime,aid,uid]);
						if(notif.length!==0)notif.pop();
						for(var address in notif){
							var tmp=notif[address].split('~',2);
							var msg=lang_script[tmp[0]][0].replace('%u0%',rs.first_name).replace('%u1%',rs.last_name).replace('%u2%',rs.class).replace('%tm%',fulltime);
							try{
								if(tmp[1].charAt(0)==='E'){
									edupage.send_message(tmp[1].substring(1,tmp[1].length),msg);
								}else if(tmp[1].charAt(0)==='T'){
									var tid=await dbq('SELECT tid FROM telegram WHERE phone=? LIMIT 1',[parseInt(tmp[1].substring(1,tmp[1].length))]);
									if(tid.length)bot.telegram.sendMessage(tid[0].tid,msg);
								}
							}catch(e){}
						}
						db.commit(err=>{
							if(err){
								db.rollback();
								return qca(res,500);
							}
							return res.end(JSON.stringify(rs));
						});
					}catch(e){
						db.rollback();
						return qca(res,500);
					}
				});
			}else res.end(JSON.stringify(rs));
			return;
		}
		if(api.type==='get_user_data'){
			if(status===3){
				var rs=await dbq('SELECT username,status,first_name,last_name,class,photo,allows,group_right,notification,last_action FROM users WHERE uid=? LIMIT 1',[api.uid]);
				if(!rs.length)return qca(res,400);
				rs=rs[0];
				var r=rs.allows;
				rs.allows=new Array();
				for(var j=0;j<r.length;j+=4){
					var tmp=await dbq('SELECT allow_info.aid,allow_info.start_date,allow_info.end_date,BIN(allow_info.nav) AS nav,allow_info.msg,allow_info.created,users.first_name,users.last_name,users.class,users.username FROM allow_info JOIN users ON allow_info.gived=users.uid WHERE allow_info.aid=? AND allow_info.users!=""',[base644int(r.substr(j,4))]);
					rs.allows.push(tmp[0]);
				}
				res.end(JSON.stringify(rs));
			}else qca(res,401);
			return;
		}
		if(api.type==='upload_picture'){
			if(status===3){
				await dbq('UPDATE users SET photo=? WHERE uid=? LIMIT 1',[api.photo,api.uid]);
				res.end('1');
			}else qca(res,401);
			return;
		}
		if(api.type==='update_profile'){
			if(status===3){
				if(api.username==='')return qca(res,400);
				if(!api.username.match(/^[0-9a-zA-Z@-@.-.]+$/))return qca(res,400);
				var rs=await dbq('SELECT COUNT(*) AS cnt FROM users WHERE username=? AND uid!=? LIMIT 1',[api.username,api.uid]);
				if(rs[0].cnt)return res.end('-');
				var sql='UPDATE users SET username=?,first_name=?,last_name=?,class=?,status=?';
				var datas=[api.username,api.first_name,api.last_name,api.class,api.status&7];
				if(api.status&4)sql+=',web=(substr(sha(rand()),1,24))';
				if(api.password!==''){
					sql+=',password=SHA2(?,256)';
					datas.push(api.password);
				}
				sql+=' WHERE uid=? LIMIT 1';
				datas.push(api.uid);
				await dbq(sql,datas);
				qca(res,200);
			}else qca(res,401);
			return;
		}
		if(api.type==='drop_qr'){
			if(status===3){
				await dbq('UPDATE users SET qr=(substr(sha(rand()),1,8)) WHERE uid=? LIMIT 1',[api.uid]);
				qca(res,200);
			}else qca(res,401);
			return;
		}
		if(api.type==='edit_group_right'){
			if(status===3){
				const mx=(await dbq('SELECT COUNT(*) AS mx FROM grp'))[0].mx;
				var str='';
				for(var i in api.data){
					const val=parseInt(api.data[i]);
					if(isNaN(val))continue;
					if(1<=val&&val<=mx)str+=int4base64(val);
				}
				await dbq('UPDATE users SET group_right=? WHERE uid=? LIMIT 1',[str,api.uid]);
				res.end('1');
			}else qca(res,401);
			return;
		}
		if(api.type==='get_edupage_users'){
			if(status===3)res.sendFile(__dirname+'/edupage_users.json');
			else qca(res,401);
			return;
		}
		if(api.type==='add_notification'){
			if(status===3){
				if(!util.isString(api.address))return qca(res,400);
				await dbq('UPDATE users SET notification=CONCAT(notification,?) WHERE uid=? LIMIT 1',[api.address.replaceAll('`','\'')+'`',api.uid]);
				res.end('1');
			}else qca(res,401);
			return;
		}
		if(api.type==='delete_notification'){
			if(status===3){
				var rs=await dbq('SELECT notification FROM users WHERE uid=? LIMIT 1',[api.uid]);
				if(!rs.length)return qca(res,401);
				var tmp=rs[0].notification;
				if(tmp!=='')tmp=tmp.slice(0,-1);
				var all=tmp.split('`');
				var flag=false;
				var msg='';
				for(var i in all)
					if(all[i]===api.address){
						flag=true;
					}else{
						msg+=all[i]+'`';
					}
				if(flag)await dbq('UPDATE users SET notification=? WHERE uid=? LIMIT 1',[msg,api.uid]);
				res.end('1');
			}else qca(res,401);
			return;
		}
		if(api.type==='get_history'){
			if(status!==0){
				var sql='';
				if(api.c.length!==0){
					var r=await dbq('SELECT uid FROM users WHERE username=?',[api.c]);
					if(r.length)sql='history.uid='+String(r[0].uid)+' AND ';
					else return res.end('[]');
				}
				var rs=await dbq('SELECT '+(status===3?'allow_info.aid,':'')+'history.tm,u.first_name AS u0,u.last_name AS u1,u.class AS u2,op.first_name AS op0,op.last_name AS op1,BIN(allow_info.nav) AS nav,allow_info.created,allow_info.msg,gv.first_name AS gv0,gv.last_name AS gv1 FROM history JOIN users AS u ON u.uid=history.uid JOIN users AS op ON op.uid=history.operator JOIN allow_info ON allow_info.aid=history.aid JOIN users AS gv ON gv.uid=allow_info.gived WHERE '+sql+'tm BETWEEN ? AND ?',[api.a,api.b]);
				res.end(JSON.stringify(rs));
			}else qca(res,401);
			return;
		}
		qca(res,400);
	}catch(e){
		qca(res,500);
	}
});
web_redirect.use((req,res)=>{return res.redirect('https://'+req.headers.host+req.url);});
db.connect(async(err)=>{
	if(err){
		console.log('::Failed to connect to the database');
		process.exit(0);
	}
	if(config.web.https_redirect)http.createServer(web_redirect).listen(config.web.http,()=>console.log('::SControl is running on port '+config.web.http));
	else http.createServer(web).listen(config.web.http,()=>console.log('::SControl is running on port '+config.web.http));
	https.createServer({key:fs.readFileSync('./ssl/ssl.key'),cert:fs.readFileSync('./ssl/ssl.cert'),},web).listen(config.web.https,()=>console.log('::SControl is running on port '+config.web.https));
});
async function profilaction(){
	var all=await dbq('SELECT aid FROM allow_info WHERE end_date<? AND users!="" ORDER BY aid DESC',[t_date()]);
	for(var id in all){
		const aid=all[id].aid;
		var rs=await dbq('SELECT users FROM allow_info WHERE aid=? LIMIT 1',[aid]);
		if(!rs.length)continue;
		var r=rs[0].users;
		for(var i=0;i<r.length;i+=4){
			var a=await dbq('SELECT allows FROM users WHERE uid=? LIMIT 1',[base644int(r.substr(i,4))]);
			if(!a.length)continue;
			a=a[0].allows;
			for(var j=0;j<a.length;j+=4){
				if(base644int(a.substr(j,4))===aid){
					await dbq('UPDATE users SET allows=? WHERE uid=? LIMIT 1',[a.substr(0,j)+a.substr(j+4,a.length-j-4),base644int(r.substr(i,4))]);
					break;
				}
			}
		}
		await dbq('UPDATE allow_info SET users=\'\' WHERE aid=?',[aid]);
	}
}
setInterval(profilaction,43200000);
profilaction();